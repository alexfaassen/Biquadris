#ifndef INPUTSTATE_H
#define INPUTSTATE_H

enum InputState {NORMAL, END_TURN, SA, LOSS};

#endif
