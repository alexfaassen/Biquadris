#ifndef MOVE_H
#define MOVE_H

enum Move {mLeft, mRight, mDown, mClockwise, mCounterClockwise};

#endif
