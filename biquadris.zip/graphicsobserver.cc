#include "graphicsobserver.h"

GraphicsObserver::GraphicsObserver(PlayerWindow* w) : window{w}{}