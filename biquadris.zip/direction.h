#ifndef DIRECT_H
#define DIRECT_H

enum Direction {Left, Right, Down};

#endif
