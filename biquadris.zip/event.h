#ifndef EVENT_H
#define EVENT_H

enum Event {beforeMove, afterMove, onTurnStart, onTurnEnd, beforeTextDisplay, onSAapplied,
            onLinesCleared, onDrop, onScoreChange, onLevelChange, onNextBlockChange};

#endif